package main

import (
	"github.com/LarsDeLeeuw/DS2024-2/pkg/gateway/v1"
)

func main() {
	gateway.RunApp()
}
