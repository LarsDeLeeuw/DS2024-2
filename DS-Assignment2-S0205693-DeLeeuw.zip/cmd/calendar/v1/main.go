package main

import (
	"github.com/LarsDeLeeuw/DS2024-2/pkg/calendar/v1"
)

func main() {
	calendar.RunApp()
}
